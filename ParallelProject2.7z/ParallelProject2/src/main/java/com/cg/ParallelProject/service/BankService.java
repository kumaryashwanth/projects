package com.cg.ParallelProject.service;

import com.cg.ParallelProject.enity.BankCustomer;

public interface BankService {
public BankCustomer createAccount(BankCustomer bank);
public int showbalance(int accnum);
public int deposit(int accnum,int deposit);
public int withdraw(int accnum,int withdraw);
public int transfer(int accnum,int transfer);
public String validateAccnum(int accnum);

}
