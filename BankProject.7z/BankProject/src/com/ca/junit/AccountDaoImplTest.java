package com.ca.junit;

import org.junit.Assert;
import org.junit.Test;

import com.ca.Dao.AccountDAO;
import com.ca.Dao.AccountDAOImpl;
import com.ca.Exception.InvalidDataException;
import com.ca.entity.Account;


public class AccountDaoImplTest {

	static AccountDAO accdao=new AccountDAOImpl();
	
	@Test
	public static void Addcustomer() throws InvalidDataException
	{
		Account acc=new Account("Yash", "Mipl", "9840502059", 50000.00);
		
		int result=accdao.addcustomer(1234, acc);
		Assert.assertEquals(1234, acc);
		Assert.assertEquals(1234,accdao.addcustomer(1234, new Account("YASH", "MIPL", "9840502059", 50000.00)));
	}
}
/*@Test
public void createAccountTest() throws CustomerNameException,CustomerNumberException,CustomerAgeException,CustomerMailIdException,CustomerAadharException
{
Customer c = new Customer("Mounika","9874563215",25,"mounika@gmail.com","456321789654","Vijayawada",523002);
Account acc = new Account("983429112",3354.0);
AccountDAO accDAO=new AccountDAOImpl();
String result=accDAO.createAccount(c,acc);

Assert.assertEquals("983429112",result);

} */