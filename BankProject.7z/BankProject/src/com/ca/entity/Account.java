package com.ca.entity;

public class Account {

	private String CustomerName;
	private String Branch;
	private String Mobno;
	private double Balance;
	public Account(String customerName, String branch, String mobno, double balance) {
		super();
		CustomerName = customerName;
		Branch = branch;
		Mobno = mobno;
		Balance = balance;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public String getBranch() {
		return Branch;
	}
	public void setBranch(String branch) {
		Branch = branch;
	}
	public String getMobno() {
		return Mobno;
	}
	public void setMobno(String mobno) {
		Mobno = mobno;
	}
	public double getBalance() {
		return Balance;
	}
	public double setBalance(double balance) {
		return Balance = balance;
	}
	@Override
	public String toString() {
		return "Account [CustomerName=" + CustomerName + ", Branch=" + Branch + ", Mobno=" + Mobno + ", Balance="
				+ Balance + "]";
	}
	
	
	
}
