package com.cg.Service;

import java.sql.SQLException;
import java.util.HashMap;
import com.cg.Entity.Account;
public interface AccountService {

	public int addcustomer(Integer a,Account a2) throws SQLException, ClassNotFoundException;
	public Account showbalance(int acc) throws ClassNotFoundException, SQLException;
	public boolean validateCustomerName(String name);
	public boolean ValidateCustomerMobileno(String cid);
	 public boolean ValidateBranch(String name);
	public void deposit(double amt,int acc) throws ClassNotFoundException, SQLException;
	public void withdraw(double res, int acc) throws ClassNotFoundException, SQLException;	
}
